#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-154-auto-functions-v1/class-agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-154-auto-functions-v1/class-agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-154-auto-functions-v1/class-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-154-auto-functions-v1/class-agent-affinity-pinned.log
export TEMIYA_REVISION=d818832144d07b8bc6d6b2ad80e31e86a9040494
export BENCH_NOTES='Four class workloads frozen before any execution atmanifest13a897b0. Fixed setup/invocation/counts/oracles,15samples3pairs, same external180s512MiB watchdog. Separatefromoriginal11. CPU0 agent1-3; no localbuilds/tests duringtiming. Keep failures/unfavorableoutcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-auto-functions-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/class-boa.json 2> /tmp/temiya-154-auto-functions-v1/class-boa.progress
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-auto-functions-v1/worker /tmp/temiya-154-auto-functions-v1/worker-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/class-same-binary.json 2> /tmp/temiya-154-auto-functions-v1/class-same-binary.progress

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-auto-functions-v1/worker /tmp/temiya-154-perf/current-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/class-beforeafter.json 2> /tmp/temiya-154-auto-functions-v1/class-beforeafter.progress
