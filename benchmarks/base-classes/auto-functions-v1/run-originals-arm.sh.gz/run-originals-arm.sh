#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-154-auto-functions-v1/agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-154-auto-functions-v1/agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-154-auto-functions-v1/agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-154-auto-functions-v1/agent-affinity-pinned.log
export TEMIYA_REVISION=d818832144d07b8bc6d6b2ad80e31e86a9040494
export BENCH_NOTES='Auto verified function candidate d818 vs frozen pre154 baseline. Unchanged original eleven workload bodies/counts/oracles;15samples3alternatingpairs; CPU0 agent1-3 no concurrent local builds/tests. Retain every outcome. Separate class reports retained.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-auto-functions-v1/worker /tmp/temiya-154-perf/baseline-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/beforeafter.json 2> /tmp/temiya-154-auto-functions-v1/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-auto-functions-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/boa.json 2> /tmp/temiya-154-auto-functions-v1/boa.progress
export TEMIYA_REVISION=fb07e6358ff6ab8d62b7e1f8f3aa7e3e1124472a
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-perf/baseline-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/baseline-boa.json 2> /tmp/temiya-154-auto-functions-v1/baseline-boa.progress
export TEMIYA_REVISION=d818832144d07b8bc6d6b2ad80e31e86a9040494
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-auto-functions-v1/worker /tmp/temiya-154-auto-functions-v1/worker-info.json 15 3 > /tmp/temiya-154-auto-functions-v1/same-binary.json 2> /tmp/temiya-154-auto-functions-v1/same-binary.progress
