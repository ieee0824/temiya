#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-154-perf/agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-154-perf/agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-154-perf/agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-154-perf/agent-affinity-pinned.log
export TEMIYA_REVISION=3bc78aee103a9254efe92f6788035d8385f4ffe5
export BENCH_NOTES='Baseclass candidate3bc78ae vs frozen150fb07 worker with identical library/Cargo inputs in pre154main36049e0. Unmodified original11 bodies/counts/oracles,15samples3pairs. CPU0 agent1-3; no local builds/tests during timing. Retain unfavorable outcomes; class workloads are separate, no classspeed claim fromoriginal11.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-perf/current-worker /tmp/temiya-154-perf/baseline-info.json 15 3 > /tmp/temiya-154-perf/beforeafter.json 2> /tmp/temiya-154-perf/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-perf/current-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-perf/boa.json 2> /tmp/temiya-154-perf/boa.progress
export TEMIYA_REVISION=fb07e6358ff6ab8d62b7e1f8f3aa7e3e1124472a
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-perf/baseline-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-perf/baseline-boa.json 2> /tmp/temiya-154-perf/baseline-boa.progress
export TEMIYA_REVISION=3bc78aee103a9254efe92f6788035d8385f4ffe5
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-perf/current-worker /tmp/temiya-154-perf/current-info.json 15 3 > /tmp/temiya-154-perf/same-binary.json 2> /tmp/temiya-154-perf/same-binary.progress
