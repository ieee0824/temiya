#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-154-perf/class-agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-154-perf/class-agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-154-perf/class-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-154-perf/class-agent-affinity-pinned.log
export TEMIYA_REVISION=3bc78aee103a9254efe92f6788035d8385f4ffe5
export BENCH_NOTES='Four class workloads frozen before any execution atmanifest13a897b0. Fixed setup/invocation/counts/oracles,15samples3pairs, same external180s512MiB watchdog. Separatefromoriginal11. CPU0 agent1-3; no localbuilds/tests duringtiming. Keep failures/unfavorableoutcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-perf/current-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-perf/class-boa.json 2> /tmp/temiya-154-perf/class-boa.progress
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-perf/current-worker /tmp/temiya-154-perf/current-info.json 15 3 > /tmp/temiya-154-perf/class-same-binary.json 2> /tmp/temiya-154-perf/class-same-binary.progress
