#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-154-lexical-v1/class-agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-154-lexical-v1/class-agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-154-lexical-v1/class-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-154-lexical-v1/class-agent-affinity-pinned.log
export TEMIYA_REVISION=2f2e61d5d77edb15e8a50a5c81d5156cc9bf80df
export BENCH_NOTES='Private lexical slot/empty-block/root-revival candidate2f2. Frozen original class4 inputs/counts/oracles,15samples3alternatingpairs. ActualBoa, same-binary, beforeafter vs frozen d818. CPU0 agent1-3; no local builds/tests during timing. Preserve all outcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-lexical-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-lexical-v1/class-boa.json 2> /tmp/temiya-154-lexical-v1/class-boa.progress
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-lexical-v1/worker /tmp/temiya-154-lexical-v1/worker-info.json 15 3 > /tmp/temiya-154-lexical-v1/class-same-binary.json 2> /tmp/temiya-154-lexical-v1/class-same-binary.progress

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-lexical-v1/worker /tmp/temiya-154-auto-functions-v1/worker-info.json 15 3 > /tmp/temiya-154-lexical-v1/class-beforeafter.json 2> /tmp/temiya-154-lexical-v1/class-beforeafter.progress
