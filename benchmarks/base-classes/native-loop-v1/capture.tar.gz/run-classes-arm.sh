#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 3039086 > /tmp/temiya-154-loop-reuse-v1/pinned/host-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 3038715 > /tmp/temiya-154-loop-reuse-v1/pinned/class-agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 3038692 >> /tmp/temiya-154-loop-reuse-v1/pinned/class-agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 3038715 > /tmp/temiya-154-loop-reuse-v1/pinned/class-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 3038692 >> /tmp/temiya-154-loop-reuse-v1/pinned/class-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 3039086 >> /tmp/temiya-154-loop-reuse-v1/pinned/class-agent-affinity-pinned.log
for pid in 3038715 3038692 3039086; do
  test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=05d2eee7171d6f658e5a1ca383c888c3a8d660ea
export BENCH_NOTES='05d2 verified loop-binding reuse, frozen 5bbae46 worker. Class4 fixed setup/body/counts/oracles unchanged;15samples3alternatingpairs,actualBoa plus identical ELF and before9970. CPU0 agent1-3; no local builds/tests during timing. All outcomes retained.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-loop-reuse-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/class-boa.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/class-boa.progress
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-loop-reuse-v1/worker /tmp/temiya-154-loop-reuse-v1/worker-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/class-same-binary.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/class-same-binary.progress

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline /tmp/temiya-154-class-workloads-v1 /tmp/temiya-154-loop-reuse-v1/worker /tmp/temiya-154-leaf-v1/worker-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/class-beforeafter.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/class-beforeafter.progress
