#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-base-classes
trap 'taskset --all-tasks --pid --cpu-list 0-3 3039086 > /tmp/temiya-154-loop-reuse-v1/pinned/original-host-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 3038715 > /tmp/temiya-154-loop-reuse-v1/pinned/original-agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 3038692 >> /tmp/temiya-154-loop-reuse-v1/pinned/original-agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 3038715 > /tmp/temiya-154-loop-reuse-v1/pinned/original-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 3038692 >> /tmp/temiya-154-loop-reuse-v1/pinned/original-agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 3039086 >> /tmp/temiya-154-loop-reuse-v1/pinned/original-agent-affinity-pinned.log
for pid in 3038715 3038692 3039086; do
  test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=05d2eee7171d6f658e5a1ca383c888c3a8d660ea
export BENCH_NOTES='05d2 frozen loop reuse 5bbae vs9970 frozen ddb beforebaseline. Unchanged original11 inputs/counts/oracles,15samples3alternatingpairs. CPU0 workers,verifiedcurrentagent+daemon+host1-3;no local builds/tests during timing. Retain all outcomes, no source superiority from identicalbinary control.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-loop-reuse-v1/worker /tmp/temiya-154-leaf-v1/worker-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/beforeafter.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-loop-reuse-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/boa.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/boa.progress
export TEMIYA_REVISION=9970cd5221bf6b74ae3543c59085a40b6d6cafa0
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-leaf-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/baseline-boa.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/baseline-boa.progress
export TEMIYA_REVISION=05d2eee7171d6f658e5a1ca383c888c3a8d660ea
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-154-loop-reuse-v1/worker /tmp/temiya-154-loop-reuse-v1/worker-info.json 15 3 > /tmp/temiya-154-loop-reuse-v1/pinned/same-binary.json 2> /tmp/temiya-154-loop-reuse-v1/pinned/same-binary.progress
