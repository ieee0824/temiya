#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-derived-classes
root=/tmp/temiya-155-class-loop-runtime-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-155-class-loop-runtime-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export BENCH_NOTES='Activate verified loop reuse for runtime frames a10e7a3 vs actualbeforec654c02. Fixed base4/derived5 sources/counts/oracles unchanged. CPU0 workers/controller; verified agents+daemon+host1-3.15samples3alternatingpairs; no local builds/tests/audits during timing. Retain all noisy/unfavorable outcomes; successful job means validity, not speed acceptance.'
for suite in class derived; do
 if [ "$suite" = class ]; then
  flags=()
  inputs=benchmarks/base-classes/class-workloads
 else
  flags=(--derived)
  inputs=benchmarks/derived-classes/workloads-v1
 fi
 export TEMIYA_REVISION=a10e7a389e76faca5c8d38f5ab4619d8d678da05
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" "$inputs" "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/$suite-boa.json" 2> "$root/$suite-boa.progress"
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" --temiya-baseline "$inputs" "$root/worker" "$root/worker-info.json" 15 3 > "$root/$suite-same-binary.json" 2> "$root/$suite-same-binary.progress"
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" --temiya-baseline "$inputs" "$root/worker" /tmp/temiya-155-class-loop-capture-v1/worker-info.json 15 3 > "$root/$suite-beforeafter.json" 2> "$root/$suite-beforeafter.progress"
 export TEMIYA_REVISION=c654c020daca34565ad181dcb63c3bbd7e6b0b70
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" "$inputs" /tmp/temiya-155-class-loop-capture-v1/worker /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/$suite-baseline-boa.json" 2> "$root/$suite-baseline-boa.progress"
done
