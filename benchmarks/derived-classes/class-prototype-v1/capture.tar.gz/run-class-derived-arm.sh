#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-derived-classes
root=/tmp/temiya-155-class-prototype-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-155-class-prototype-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export BENCH_NOTES='Immutable direct base-class prototype reuse e11890a vs actualbefore306c32c. Fixed base4/derived5 sources/counts/oracles unchanged. CPU0 workers/controller; verified agents+daemon+host1-3.15samples3alternatingpairs; no local builds/tests/audits during timing. Retain all noisy/unfavorable outcomes; successful job means validity, not speed acceptance.'
for suite in class derived; do
 if [ "$suite" = class ]; then
  flags=()
  inputs=benchmarks/base-classes/class-workloads
 else
  flags=(--derived)
  inputs=benchmarks/derived-classes/workloads-v1
 fi
 export TEMIYA_REVISION=e11890a12fbd67a395dafad3e43b763e14dd29de
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" "$inputs" "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/$suite-boa.json" 2> "$root/$suite-boa.progress"
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" --temiya-baseline "$inputs" "$root/worker" "$root/worker-info.json" 15 3 > "$root/$suite-same-binary.json" 2> "$root/$suite-same-binary.progress"
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" --temiya-baseline "$inputs" "$root/worker" /tmp/temiya-155-class-bridge-v1/worker-info.json 15 3 > "$root/$suite-beforeafter.json" 2> "$root/$suite-beforeafter.progress"
 export TEMIYA_REVISION=306c32c24a6c678276284c6ff898713137447370
 taskset --cpu-list 0 node scripts/compare-class-workloads.mjs "${flags[@]}" "$inputs" /tmp/temiya-155-class-bridge-v1/worker /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/$suite-baseline-boa.json" 2> "$root/$suite-baseline-boa.progress"
done
