#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-derived-classes
root=/tmp/temiya-155-delegation-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-155-delegation-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=8b019733ed8e08d3bb8a31319501a4d3c08bf070
export BENCH_NOTES='Sole-super activation/argument-list elision8b01973 vs actualbefore2be. Fixed derived5 sources/counts/oracles unchanged. CPU0 workers/controller; verified live agent+daemon+host1-3.15samples3alternatingpairs; no local builds/tests during timing. Retain all noisy and unfavorable outcomes; job success is validity, not a speed pass.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --derived benchmarks/derived-classes/workloads-v1 "$root/worker" /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "$root/derived-boa.json" 2> "$root/derived-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --derived --temiya-baseline benchmarks/derived-classes/workloads-v1 "$root/worker" "$root/worker-info.json" 15 3 > "$root/derived-same-binary.json" 2> "$root/derived-same-binary.progress"

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --derived --temiya-baseline benchmarks/derived-classes/workloads-v1 "$root/worker" /tmp/temiya-155-view-index-v1/worker-info.json 15 3 > "$root/derived-beforeafter.json" 2> "$root/derived-beforeafter.progress"

export TEMIYA_REVISION=2be3d7c82091d27f7d2fae58a346c44144d3666b
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --derived benchmarks/derived-classes/workloads-v1 /tmp/temiya-155-view-index-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "/tmp/temiya-155-delegation-v1/derived-baseline-boa.json" 2> "/tmp/temiya-155-delegation-v1/derived-baseline-boa.progress"
