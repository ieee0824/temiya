#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-derived-classes
root=/tmp/temiya-155-initial-v1
for pid in 3038715 3038692 3039086; do test -d /proc/$pid; done
trap 'for pid in 3038715 3038692 3039086; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-155-initial-v1/agent-affinity-restored.log; done' EXIT
for pid in 3038715 3038692 3039086; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=061ffcded6b11f31fa49b967fecce1842c467984
export BENCH_NOTES='Initial derived constructor implementation061ffcd. Fixed derived5 suite frozen before first execution. CPU0 workers/controller, verified current agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa andidenticalworker. Retain all unfavorable/noisy outcomes. Old154 cannot execute this suite, so not used as a numeric derived baseline.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --derived benchmarks/derived-classes/workloads-v1 "$root/worker" /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "$root/derived-boa.json" 2> "$root/derived-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --derived --temiya-baseline benchmarks/derived-classes/workloads-v1 "$root/worker" "$root/worker-info.json" 15 3 > "$root/derived-same-binary.json" 2> "$root/derived-same-binary.progress"
