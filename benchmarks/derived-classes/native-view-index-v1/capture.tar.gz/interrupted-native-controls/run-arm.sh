#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-derived-classes
root=/tmp/temiya-155-native-controls-v1
for pid in 3038715 3038692 3039086; do test -d /proc/$pid; done
trap 'for pid in 3038715 3038692 3039086; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-155-native-controls-v1/agent-affinity-restored.log; done' EXIT
for pid in 3038715 3038692 3039086; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done

export TEMIYA_REVISION=06ceeee645204673aa06f6c407fa2cfa9e536c17
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-155-native-prototypes-v1/worker /tmp/temiya-155-arguments-v1/worker-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/original-beforeafter.json" 2> "/tmp/temiya-155-native-controls-v1/original-beforeafter.progress"
export TEMIYA_REVISION=06ceeee645204673aa06f6c407fa2cfa9e536c17
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-155-native-prototypes-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/original-boa.json" 2> "/tmp/temiya-155-native-controls-v1/original-boa.progress"
export TEMIYA_REVISION=f1ed7c0ab3260de78cbf169651e5093ca8239aa0
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-155-arguments-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/original-baseline-boa.json" 2> "/tmp/temiya-155-native-controls-v1/original-baseline-boa.progress"
export TEMIYA_REVISION=06ceeee645204673aa06f6c407fa2cfa9e536c17
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-155-native-prototypes-v1/worker /tmp/temiya-155-native-prototypes-v1/worker-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/original-same-binary.json" 2> "/tmp/temiya-155-native-controls-v1/original-same-binary.progress"
export TEMIYA_REVISION=06ceeee645204673aa06f6c407fa2cfa9e536c17
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline benchmarks/base-classes/class-workloads /tmp/temiya-155-native-prototypes-v1/worker /tmp/temiya-155-arguments-v1/worker-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/class-beforeafter.json" 2> "/tmp/temiya-155-native-controls-v1/class-beforeafter.progress"
export TEMIYA_REVISION=06ceeee645204673aa06f6c407fa2cfa9e536c17
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs benchmarks/base-classes/class-workloads /tmp/temiya-155-native-prototypes-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/class-boa.json" 2> "/tmp/temiya-155-native-controls-v1/class-boa.progress"
export TEMIYA_REVISION=f1ed7c0ab3260de78cbf169651e5093ca8239aa0
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs benchmarks/base-classes/class-workloads /tmp/temiya-155-arguments-v1/worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/class-baseline-boa.json" 2> "/tmp/temiya-155-native-controls-v1/class-baseline-boa.progress"
export TEMIYA_REVISION=06ceeee645204673aa06f6c407fa2cfa9e536c17
export BENCH_NOTES='Native-prototype06ceeee vs argumentsf1; original11 and fixed base4 unchanged. CPU0 workers/controller, verified live agent+daemon+host1-3; no local builds/tests during timing.15samples3alternatingpairs;actualBoa, direct baselineBoa, beforeafter, identicalworker. Preserve all unfavorable/noisy outcomes.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --temiya-baseline benchmarks/base-classes/class-workloads /tmp/temiya-155-native-prototypes-v1/worker /tmp/temiya-155-native-prototypes-v1/worker-info.json 15 3 > "/tmp/temiya-155-native-controls-v1/class-same-binary.json" 2> "/tmp/temiya-155-native-controls-v1/class-same-binary.progress"
