/*---
flags: [async]
---*/
async function* read(){yield 42;}read().next().then(()=>$DONE(),$DONE);
