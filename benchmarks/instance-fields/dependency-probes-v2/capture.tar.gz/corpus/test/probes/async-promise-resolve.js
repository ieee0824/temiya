/*---
flags: [async]
---*/
async function read(){return 42;}read().then(v=>Promise.resolve(v)).then(()=>$DONE(),$DONE);
