/*---
flags: [async]
---*/
async function read(){return 42;}read().then(v=>{if(v!==42)throw new Error("value");}).then(()=>$DONE(),$DONE);
