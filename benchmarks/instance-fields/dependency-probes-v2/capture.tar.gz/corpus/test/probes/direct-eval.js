/*---
flags: []
---*/
function read(){return eval("40+2;");}if(read()!==42)throw new Error("value");
