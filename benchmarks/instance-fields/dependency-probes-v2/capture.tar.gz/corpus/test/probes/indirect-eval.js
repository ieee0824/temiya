/*---
flags: []
---*/
if((0,eval)("40+2;")!==42)throw new Error("value");
