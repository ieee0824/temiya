/*---
flags: []
---*/
class C{#value=42;read(){return this.#value;}}if(new C().read()!==42)throw new Error("value");
