/*---
flags: []
---*/
class C{#read(){return 42;}read(){return this.#read();}}if(new C().read()!==42)throw new Error("value");
