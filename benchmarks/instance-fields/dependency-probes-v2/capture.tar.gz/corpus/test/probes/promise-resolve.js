/*---
flags: []
---*/
Promise.resolve(42);
