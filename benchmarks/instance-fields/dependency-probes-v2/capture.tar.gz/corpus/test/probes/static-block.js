/*---
flags: []
---*/
class C{static{this.value=42;}}if(C.value!==42)throw new Error("value");
