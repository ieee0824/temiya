/*---
flags: []
---*/
class C{static value=42;}if(C.value!==42)throw new Error("value");
