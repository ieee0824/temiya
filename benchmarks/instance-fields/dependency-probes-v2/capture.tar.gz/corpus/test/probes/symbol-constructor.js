/*---
flags: []
---*/
if(typeof Symbol()!=="symbol" || Symbol()===Symbol())throw new Error("Symbol identity missing");
