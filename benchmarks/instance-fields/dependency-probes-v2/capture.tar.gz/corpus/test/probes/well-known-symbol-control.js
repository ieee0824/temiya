/*---
flags: []
---*/
if(typeof Symbol.iterator!=="symbol" || Symbol.iterator===Symbol.toStringTag)throw new Error("well-known identity");
