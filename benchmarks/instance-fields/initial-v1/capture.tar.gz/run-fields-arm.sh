#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-instance-fields
root=/tmp/temiya-157-initial-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-157-initial-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=3f86f2467a0bf25753a0ada2d10ed46fbc5a5053
export BENCH_NOTES='First instance-field source3f86f24 before namespace correction. Correctness/oracle probes only do not qualify merge. Fixed5 inputs/counts/oracles unchanged.15samples3alternatingpairs. CPU0workers/controller; agent/daemon/host1-3. No local tests/builds/audits. Preserve all noise/adverse results. Feature absent before157, so initial capture uses Boa and identical-binary controls; initialsource becomes beforebaseline for later optimization.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --fields benchmarks/instance-fields/workloads-v1 "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/fields-boa.json" 2> "$root/fields-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --fields --temiya-baseline benchmarks/instance-fields/workloads-v1 "$root/worker" "$root/worker-info.json" 15 3 > "$root/fields-same-binary.json" 2> "$root/fields-same-binary.progress"
