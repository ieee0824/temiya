use boa_engine::{Context, Source};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let file = std::env::args().nth(1).ok_or("WORKLOAD_JSON required")?;
    let data: serde_json::Value = serde_json::from_slice(&std::fs::read(file)?)?;
    let mut context = Context::default();
    context.eval(Source::from_bytes(data["setup"].as_str().ok_or("setup")?))
        .map_err(|e| format!("setup: {e}"))?;
    let value = context.eval(Source::from_bytes(data["invocation"].as_str().ok_or("invocation")?))
        .map_err(|e| format!("invocation: {e}"))?;
    let expected = data["expected"].as_f64().ok_or("expected")?;
    if value.as_number() != Some(expected) {
        return Err(format!("expected {expected}, got {value:?}").into());
    }
    println!("{}", serde_json::json!({"validated":true,"expected":expected,"scope":"bare pinned vendored Boa Context; no timing or sandbox embedding"}));
    Ok(())
}
