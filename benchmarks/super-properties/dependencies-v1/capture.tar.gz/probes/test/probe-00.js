/*---
description: Authored dependency probe Object.keys
flags: [noStrict]
---*/

assert.sameValue((typeof Object.keys === 'undefined'), true);
