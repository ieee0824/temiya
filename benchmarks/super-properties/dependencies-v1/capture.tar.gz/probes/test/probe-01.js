/*---
description: Authored dependency probe WeakMap.has
flags: [noStrict]
---*/

assert.sameValue((typeof WeakMap.prototype.has === 'undefined'), true);
