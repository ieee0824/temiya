/*---
description: Authored dependency probe ArrayBuffer.slice
flags: [noStrict]
---*/

assert.sameValue((typeof ArrayBuffer.prototype.slice === 'undefined'), true);
