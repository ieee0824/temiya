/*---
description: Authored dependency probe Date.getFullYear
flags: [noStrict]
---*/

assert.sameValue((typeof Date.prototype.getFullYear === 'undefined'), true);
