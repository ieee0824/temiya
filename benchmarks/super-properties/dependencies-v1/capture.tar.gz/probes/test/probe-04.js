/*---
description: Authored dependency probe Number.toExponential
flags: [noStrict]
---*/

assert.sameValue((typeof Number.prototype.toExponential === 'undefined'), true);
