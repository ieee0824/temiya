/*---
description: Authored dependency probe String.trim
flags: [noStrict]
---*/

assert.sameValue((typeof String.prototype.trim === 'undefined'), true);
