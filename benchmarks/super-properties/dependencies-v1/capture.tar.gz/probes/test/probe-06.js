/*---
description: Authored dependency probe RegExp.test
flags: [noStrict]
---*/

assert.sameValue((typeof RegExp.prototype.test === 'undefined'), true);
