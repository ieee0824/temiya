/*---
description: Authored dependency probe DataView.buffer
flags: [noStrict]
---*/

assert.sameValue((new DataView(new ArrayBuffer(8)).buffer === undefined), true);
