/*---
description: Authored dependency probe Map.size
flags: [noStrict]
---*/

assert.sameValue((new Map().size === undefined), true);
