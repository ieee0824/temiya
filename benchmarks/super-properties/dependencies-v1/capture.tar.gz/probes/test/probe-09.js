/*---
description: Authored dependency probe Set.size
flags: [noStrict]
---*/

assert.sameValue((new Set().size === undefined), true);
