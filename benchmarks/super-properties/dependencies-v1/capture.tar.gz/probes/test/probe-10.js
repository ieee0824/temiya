/*---
description: Authored dependency probe Error.message
flags: [noStrict]
---*/

assert.sameValue((Object.getOwnPropertyDescriptor(new Error('message'), 'message') === undefined), true);
