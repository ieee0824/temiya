/*---
description: Authored dependency probe NativeErrors
flags: [noStrict]
---*/

assert.sameValue((typeof EvalError === 'undefined' && typeof URIError === 'undefined'), true);
