/*---
description: Authored dependency probe Boolean.payload
flags: [noStrict]
---*/

assert.sameValue(((new Boolean(true)).valueOf() !== true), true);
