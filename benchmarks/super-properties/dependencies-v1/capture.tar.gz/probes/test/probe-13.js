/*---
description: Authored dependency probe Symbol.call
flags: [noStrict]
---*/

assert.sameValue((Symbol('test') === undefined), true);
