/*---
description: Authored dependency probe Promise.executor
flags: [noStrict]
---*/
let threw = false; try { new Promise(); } catch(e) { threw = e instanceof TypeError; } 
assert.sameValue((threw === false), true);
