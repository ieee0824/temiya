/*---
description: Authored dependency probe RegExp.lastIndex
flags: [noStrict]
---*/

assert.sameValue((Object.getOwnPropertyDescriptor(new RegExp('39?'), 'lastIndex') === undefined), true);
