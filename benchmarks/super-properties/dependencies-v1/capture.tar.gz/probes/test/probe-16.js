/*---
description: Authored dependency probe parseInt
flags: [noStrict]
---*/

assert.sameValue((typeof parseInt === 'undefined'), true);
