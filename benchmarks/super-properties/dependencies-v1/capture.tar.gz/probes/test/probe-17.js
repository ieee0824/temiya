/*---
description: Authored dependency probe eval
flags: [noStrict]
---*/

assert.sameValue((typeof eval === 'undefined'), true);
