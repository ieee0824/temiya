/*---
description: Authored dependency probe TypedArray.globals
flags: [noStrict]
---*/

assert.sameValue((typeof Float64Array === 'undefined' && typeof Uint8Array === 'undefined'), true);
