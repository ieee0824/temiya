/*---
description: Authored dependency probe Function.dynamic
flags: [noStrict]
---*/

assert.sameValue((typeof (new Function('return 42;')) !== 'function'), true);
