/*---
description: Authored dependency probe IteratorClose
flags: [noStrict]
---*/
let closed = false; let count = 0; let iterable = { [Symbol.iterator]() { return this; }, next() { count++; return { value: 1, done: count > 1 }; }, return() { closed = true; return {}; } }; for (let x of iterable) { break; } 
assert.sameValue((closed === false), true);
