/*---
description: Authored dependency probe Spread.generatorThrow
flags: [noStrict]
---*/
function normal() {} let caught = false; try { normal(...function*() { throw 42; }()); } catch(e) { caught = e === 42; } 
assert.sameValue((caught === false), true);
