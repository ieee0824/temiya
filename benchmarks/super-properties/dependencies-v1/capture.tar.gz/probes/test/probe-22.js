/*---
description: Authored dependency probe Object.freeze
flags: [noStrict]
---*/
assert.sameValue((typeof Object.freeze === 'undefined'),true);
