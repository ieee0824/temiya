/*---
description: Authored dependency probe String.toLowerCase
flags: [noStrict]
---*/
assert.sameValue((typeof String.prototype.toLowerCase === 'undefined'),true);
