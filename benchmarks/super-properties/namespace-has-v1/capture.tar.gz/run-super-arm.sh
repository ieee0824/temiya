#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-super-properties
root=/tmp/temiya-156-namespace-has-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-156-namespace-has-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=299e8d8154f075c8f5169ae4651ad0f7b28bad0f
export BENCH_NOTES='Namespace membership fix299e8d8 vs preceding object capture5fc8f42. Fixed super5 sources/counts/oracles unchanged. CPU0 workers/controller; verified agent/daemon/host1-3.15samples3alternatingpairs. No concurrent local builds/tests/audits. Retain all adverse/noisy observations; job success is validity, not a speed pass.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/super-boa.json" 2> "$root/super-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" "$root/worker-info.json" 15 3 > "$root/super-same-binary.json" 2> "$root/super-same-binary.progress"

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-156-object-capture-v1/worker-info.json 15 3 > "$root/super-beforeafter.json" 2> "$root/super-beforeafter.progress"

export TEMIYA_REVISION=5fc8f42092f186d196f325b68187fcd83c8c7c88
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 /tmp/temiya-156-object-capture-v1/worker /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "/tmp/temiya-156-namespace-has-v1/super-baseline-boa.json" 2> "/tmp/temiya-156-namespace-has-v1/super-baseline-boa.progress"
