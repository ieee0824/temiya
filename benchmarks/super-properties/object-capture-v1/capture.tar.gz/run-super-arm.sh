#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-super-properties
root=/tmp/temiya-156-object-capture-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-156-object-capture-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=5fc8f42092f186d196f325b68187fcd83c8c7c88
export BENCH_NOTES='Object literal loop-header capture proof5fc8f42 vs integrated main55907d5. Fixed super-property5 sources/counts/oracles unchanged. CPU0 workers/controller; verified agent+daemon+host1-3.15samples3alternatingpairs. No concurrent local builds/tests/audits. Retain every noisy/adverse outcome.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/super-boa.json" 2> "$root/super-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" "$root/worker-info.json" 15 3 > "$root/super-same-binary.json" 2> "$root/super-same-binary.progress"

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-156-main155-v1/worker-info.json 15 3 > "$root/super-beforeafter.json" 2> "$root/super-beforeafter.progress"

export TEMIYA_REVISION=55907d5acfedb8eb8ceba0df19de80399c4e4203
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 /tmp/temiya-156-main155-v1/worker /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "/tmp/temiya-156-object-capture-v1/super-baseline-boa.json" 2> "/tmp/temiya-156-object-capture-v1/super-baseline-boa.progress"
