#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-super-properties
root=/tmp/temiya-156-sloppy-leaf-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-156-sloppy-leaf-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=a4c25776352b6edf205441e64a42bf0c10ebb762
export BENCH_NOTES='Normalized sloppy leaf callsa4c2577 vs actualbefore23a809c. Fixed super-property5 sources/counts/oracles unchanged. CPU0 workers/controller; live verified agent+daemon+host1-3.15samples3alternatingpairs; no local builds/tests/audits during timing. Retain all noisy/unfavorable outcomes; job success is validity, not a speed pass.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/super-boa.json" 2> "$root/super-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" "$root/worker-info.json" 15 3 > "$root/super-same-binary.json" 2> "$root/super-same-binary.progress"

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-156-ast-arguments-v1/worker-info.json 15 3 > "$root/super-beforeafter.json" 2> "$root/super-beforeafter.progress"

export TEMIYA_REVISION=23a809c4c639f95ca8b09371111f50ffbc0dffa7
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 /tmp/temiya-156-ast-arguments-v1/worker /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "/tmp/temiya-156-sloppy-leaf-v1/super-baseline-boa.json" 2> "/tmp/temiya-156-sloppy-leaf-v1/super-baseline-boa.progress"
