#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-super-properties
root=/tmp/temiya-156-super-binding-v1
for pid in 3281415 3281392 3281782; do test -d /proc/$pid; done
trap 'for pid in 3281415 3281392 3281782; do taskset --all-tasks --pid --cpu-list 0-3 "$pid" >> /tmp/temiya-156-super-binding-v1/agent-affinity-restored.log; done' EXIT
for pid in 3281415 3281392 3281782; do
 taskset --all-tasks --pid --cpu-list 1-3 "$pid" >> "$root/agent-affinity-pinned.log"
 test "$(awk '/^Cpus_allowed_list:/{print $2}' /proc/$pid/status)" = 1-3
done
export TEMIYA_REVISION=d7aa9a07e79c95507f73c5a95fb0c12b4ac9226d
export BENCH_NOTES='Resolve super receiver/function in one record readd7aa9a0 vs actualbefore44bb215. Fixed super-property5 sources/counts/oracles unchanged. CPU0 workers/controller; live verified agent+daemon+host1-3.15samples3alternatingpairs; no local builds/tests/audits during timing. Retain all noisy/unfavorable outcomes; job success is validity, not a speed pass.'
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "$root/super-boa.json" 2> "$root/super-boa.progress"
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" "$root/worker-info.json" 15 3 > "$root/super-same-binary.json" 2> "$root/super-same-binary.progress"

taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super --temiya-baseline benchmarks/super-properties/workloads-v3 "$root/worker" /tmp/temiya-156-home-root-v1/worker-info.json 15 3 > "$root/super-beforeafter.json" 2> "$root/super-beforeafter.progress"

export TEMIYA_REVISION=44bb2157575a1703529491d7d4c4784e9174591e
taskset --cpu-list 0 node scripts/compare-class-workloads.mjs --super benchmarks/super-properties/workloads-v3 /tmp/temiya-156-home-root-v1/worker /tmp/temiya-boa-reference-v1/build-info.json 15 3 > "/tmp/temiya-156-super-binding-v1/super-baseline-boa.json" 2> "/tmp/temiya-156-super-binding-v1/super-baseline-boa.progress"
