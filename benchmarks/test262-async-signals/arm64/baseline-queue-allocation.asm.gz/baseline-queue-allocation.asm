
/tmp/temiya-148-perf/baseline-worker:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000066854 <_RNvMs4_NtNtCs9tnobabsVEO_6temiya7runtime7managedNtB5_7Runtime18allocate_job_queue>:
   66854:	d10383ff 	sub	sp, sp, #0xe0
   66858:	a90b7bfd 	stp	x29, x30, [sp, #176]
   6685c:	a90c57f6 	stp	x22, x21, [sp, #192]
   66860:	a90d4ff4 	stp	x20, x19, [sp, #208]
   66864:	9102c3fd 	add	x29, sp, #0xb0
   66868:	ad400821 	ldp	q1, q2, [x1]
   6686c:	9100c3f6 	add	x22, sp, #0x30
   66870:	3dc01020 	ldr	q0, [x1, #64]
   66874:	52800028 	mov	w8, #0x1                   	// #1
   66878:	aa0003f4 	mov	x20, x0
   6687c:	f90023ff 	str	xzr, [sp, #64]
   66880:	3c8582c0 	stur	q0, [x22, #88]
   66884:	4e080d00 	dup	v0.2d, x8
   66888:	f9402828 	ldr	x8, [x1, #80]
   6688c:	3c8483e1 	stur	q1, [sp, #72]
   66890:	3c8583e2 	stur	q2, [sp, #88]
   66894:	ad410821 	ldp	q1, q2, [x1, #32]
   66898:	3d800fe0 	str	q0, [sp, #48]
   6689c:	f9004fe8 	str	x8, [sp, #152]
   668a0:	3c8683e1 	stur	q1, [sp, #104]
   668a4:	3c8783e2 	stur	q2, [sp, #120]
   668a8:	97ffc109 	bl	56ccc <_RNvCs5fGHjzWXRav_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
   668ac:	52800e00 	mov	w0, #0x70                  	// #112
   668b0:	52800101 	mov	w1, #0x8                   	// #8
   668b4:	97ffc102 	bl	56cbc <_RNvCs5fGHjzWXRav_7___rustc12___rust_alloc>
   668b8:	b40010c0 	cbz	x0, 66ad0 <_RNvMs4_NtNtCs9tnobabsVEO_6temiya7runtime7managedNtB5_7Runtime18allocate_job_queue+0x27c>
   668bc:	ad4387e0 	ldp	q0, q1, [sp, #112]
   668c0:	aa0003f3 	mov	x19, x0
   668c4:	3dc01ac2 	ldr	q2, [x22, #96]
   668c8:	f9400294 	ldr	x20, [x20]
   668cc:	f90007e0 	str	x0, [sp, #8]
