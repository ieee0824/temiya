
/tmp/temiya-148-signals-perf/current-worker:     file format elf64-littleaarch64


Disassembly of section .text:

00000000000d1ca0 <_RNvMs4_NtNtCs9tnobabsVEO_6temiya7runtime7managedNtB5_7Runtime18allocate_job_queue>:
   d1ca0:	d10343ff 	sub	sp, sp, #0xd0
   d1ca4:	a90a7bfd 	stp	x29, x30, [sp, #160]
   d1ca8:	f9005bf5 	str	x21, [sp, #176]
   d1cac:	a90c4ff4 	stp	x20, x19, [sp, #192]
   d1cb0:	910283fd 	add	x29, sp, #0xa0
   d1cb4:	ad400821 	ldp	q1, q2, [x1]
   d1cb8:	52800028 	mov	w8, #0x1                   	// #1
   d1cbc:	3dc01020 	ldr	q0, [x1, #64]
   d1cc0:	aa0003f4 	mov	x20, x0
   d1cc4:	f90023ff 	str	xzr, [sp, #64]
   d1cc8:	3c8883e0 	stur	q0, [sp, #136]
   d1ccc:	4e080d00 	dup	v0.2d, x8
   d1cd0:	3c8483e1 	stur	q1, [sp, #72]
   d1cd4:	3c8583e2 	stur	q2, [sp, #88]
   d1cd8:	ad410821 	ldp	q1, q2, [x1, #32]
   d1cdc:	3d800fe0 	str	q0, [sp, #48]
   d1ce0:	3c8683e1 	stur	q1, [sp, #104]
   d1ce4:	3c8783e2 	stur	q2, [sp, #120]
   d1ce8:	97fe1419 	bl	56d4c <_RNvCs5fGHjzWXRav_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
   d1cec:	52800d00 	mov	w0, #0x68                  	// #104
   d1cf0:	52800101 	mov	w1, #0x8                   	// #8
   d1cf4:	97fe1412 	bl	56d3c <_RNvCs5fGHjzWXRav_7___rustc12___rust_alloc>
   d1cf8:	b40011e0 	cbz	x0, d1f34 <_RNvMs4_NtNtCs9tnobabsVEO_6temiya7runtime7managedNtB5_7Runtime18allocate_job_queue+0x294>
   d1cfc:	ad4387e0 	ldp	q0, q1, [sp, #112]
   d1d00:	aa0003f3 	mov	x19, x0
   d1d04:	f9404be8 	ldr	x8, [sp, #144]
   d1d08:	f9400294 	ldr	x20, [x20]
   d1d0c:	f90007e0 	str	x0, [sp, #8]
