
/tmp/temiya-148-perf/current-worker:     file format elf64-littleaarch64


Disassembly of section .text:

000000000008465c <_RNvMs4_NtNtCs9tnobabsVEO_6temiya7runtime7managedNtB5_7Runtime18allocate_job_queue>:
   8465c:	d10403ff 	sub	sp, sp, #0x100
   84660:	a90d7bfd 	stp	x29, x30, [sp, #208]
   84664:	a90e57f6 	stp	x22, x21, [sp, #224]
   84668:	a90f4ff4 	stp	x20, x19, [sp, #240]
   8466c:	910343fd 	add	x29, sp, #0xd0
   84670:	ad420420 	ldp	q0, q1, [x1, #64]
   84674:	9100c3f6 	add	x22, sp, #0x30
   84678:	3dc01822 	ldr	q2, [x1, #96]
   8467c:	52800028 	mov	w8, #0x1                   	// #1
   84680:	aa0003f4 	mov	x20, x0
   84684:	f90023ff 	str	xzr, [sp, #64]
   84688:	3c8582c0 	stur	q0, [x22, #88]
   8468c:	4e080d00 	dup	v0.2d, x8
   84690:	f9403828 	ldr	x8, [x1, #112]
   84694:	3c8682c1 	stur	q1, [x22, #104]
   84698:	3c8782c2 	stur	q2, [x22, #120]
   8469c:	ad400821 	ldp	q1, q2, [x1]
   846a0:	3d800fe0 	str	q0, [sp, #48]
   846a4:	f9005fe8 	str	x8, [sp, #184]
   846a8:	3c8483e1 	stur	q1, [sp, #72]
   846ac:	ad410420 	ldp	q0, q1, [x1, #32]
   846b0:	3c8583e2 	stur	q2, [sp, #88]
   846b4:	3c8683e0 	stur	q0, [sp, #104]
   846b8:	3c8783e1 	stur	q1, [sp, #120]
   846bc:	97ff49a4 	bl	56d4c <_RNvCs5fGHjzWXRav_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
   846c0:	52801200 	mov	w0, #0x90                  	// #144
   846c4:	52800101 	mov	w1, #0x8                   	// #8
   846c8:	97ff499d 	bl	56d3c <_RNvCs5fGHjzWXRav_7___rustc12___rust_alloc>
   846cc:	b4001100 	cbz	x0, 848ec <_RNvMs4_NtNtCs9tnobabsVEO_6temiya7runtime7managedNtB5_7Runtime18allocate_job_queue+0x290>
