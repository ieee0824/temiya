#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-test262-async-runner
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-148-signals-perf/agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-148-signals-perf/agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-148-signals-perf/agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-148-signals-perf/agent-affinity-pinned.log
export TEMIYA_REVISION=30d6c412277cb7c417277eeff693dfb17ed2c50d
export BENCH_NOTES='Lazy rejection/checkpoint sidecar candidate30d vs originalbase858; original11 bodies/counts/oracles and15samples3pairs unchanged; four prespecified reports; CPU0 agent CPUs1-3; all builds and functional/Miri tests terminal before timing; new frozen ELF; retain all unfavorable observations.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-signals-perf/current-worker /tmp/temiya-148-perf/baseline-info.json 15 3 > /tmp/temiya-148-signals-perf/beforeafter.json 2> /tmp/temiya-148-signals-perf/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-signals-perf/current-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-148-signals-perf/boa.json 2> /tmp/temiya-148-signals-perf/boa.progress
export TEMIYA_REVISION=858afcce22c9ec50bb94f7630fad0f6f298ce821
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-perf/baseline-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-148-signals-perf/baseline-boa.json 2> /tmp/temiya-148-signals-perf/baseline-boa.progress
export TEMIYA_REVISION=30d6c412277cb7c417277eeff693dfb17ed2c50d
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-signals-perf/current-worker /tmp/temiya-148-signals-perf/current-info.json 15 3 > /tmp/temiya-148-signals-perf/same-binary.json 2> /tmp/temiya-148-signals-perf/same-binary.progress
