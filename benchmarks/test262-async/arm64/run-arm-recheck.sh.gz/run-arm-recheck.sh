#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-test262-async-runner
if test -e /tmp/temiya-148-perf/beforeafter-recheck.json; then
  echo 'The single planned replay already has an output; refusing another run.' >&2
  exit 1
fi
node scripts/audit-original-workload-records.mjs /tmp/temiya-148-perf/beforeafter.json /tmp/temiya-148-perf/boa.json /tmp/temiya-148-perf/baseline-boa.json /tmp/temiya-148-perf/same-binary.json > /tmp/temiya-148-perf/four-original-arm-reports-audit.json
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-148-perf/recheck-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-148-perf/recheck-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-148-perf/recheck-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-148-perf/recheck-affinity-pinned.log
export TEMIYA_REVISION=abbeac6b36767c0df6565bcce7e8b066bdaa0c06
export BENCH_NOTES='One predeclared full before/after replay to investigate initial ARM proto-method pair1 regression; all four initial reports retained; same frozen release ELFs and original11/15samples/3pairs/oracles/gates; CPU0, agent CPUs1-3; all builds/tests terminal; never repeat until favorable.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-perf/current-worker /tmp/temiya-148-perf/baseline-info.json 15 3 > /tmp/temiya-148-perf/beforeafter-recheck.json 2> /tmp/temiya-148-perf/beforeafter-recheck.progress
