#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-test262-async-runner
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-148-perf/agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-148-perf/agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-148-perf/agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-148-perf/agent-affinity-pinned.log
export TEMIYA_REVISION=abbeac6b36767c0df6565bcce7e8b066bdaa0c06
export BENCH_NOTES='ARM64 guestCPU0; agent threads on CPUs1-3; release features[]; all local builds and functional tests terminal before timing; unchanged original eleven bodies/counts/oracles, 15 samples and three alternating pairs. Controls preserve all outcomes.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-perf/current-worker /tmp/temiya-148-perf/baseline-info.json 15 3 > /tmp/temiya-148-perf/beforeafter.json 2> /tmp/temiya-148-perf/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-perf/current-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-148-perf/boa.json 2> /tmp/temiya-148-perf/boa.progress
export TEMIYA_REVISION=858afcce22c9ec50bb94f7630fad0f6f298ce821
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-perf/baseline-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-148-perf/baseline-boa.json 2> /tmp/temiya-148-perf/baseline-boa.progress
export TEMIYA_REVISION=abbeac6b36767c0df6565bcce7e8b066bdaa0c06
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-148-perf/current-worker /tmp/temiya-148-perf/current-info.json 15 3 > /tmp/temiya-148-perf/same-binary.json 2> /tmp/temiya-148-perf/same-binary.progress
