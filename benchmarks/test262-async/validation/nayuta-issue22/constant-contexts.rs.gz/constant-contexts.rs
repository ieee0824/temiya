struct Token<const N: usize>;
fn outer(xs: &[u8]) {
    for _ in xs {
        let array = [0u8; {
            let mut i = 0;
            while i < 4 { i += 1; }
            i
        }];
        let _ = array;
        let _ = Token::<{
            let mut i = 0;
            while i < 4 { i += 1; }
            i
        }>;
    }
}
fn main() { outer(&[1, 2, 3]); }
