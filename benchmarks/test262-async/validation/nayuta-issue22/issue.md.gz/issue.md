## 問題

v0.3.1 の #21 で、#20 の const 宣言の再現例は修正されていることを実 CLI で確認しました（外側・初期化式とも深さ1）。ありがとうございます。

一方、配列の繰り返し式の長さと const generic 引数の定数式では、外側の実行時ループの深さが引き継がれ、コンパイル時評価を `O(N^2)` と誤検出します。const 宣言・inline const とは異なる AST の評価コンテキストについての follow-up です。

## 再現

v0.3.1 / `c1d7877b0245d4e8ff8bcad857f04513a2e46e11` を未変更でビルドし、次を `constant-contexts.rs` に保存します。

```rust
struct Token<const N: usize>;
fn outer(xs: &[u8]) {
    for _ in xs {
        let array = [0u8; {
            let mut i = 0;
            while i < 4 { i += 1; }
            i
        }];
        let _ = array;
        let _ = Token::<{
            let mut i = 0;
            while i < 4 { i += 1; }
            i
        }>;
    }
}
fn main() { outer(&[1, 2, 3]); }
```

`rustc constant-contexts.rs` は成功します。

`nayuta constant-contexts.rs` の実際の出力:

```text
constant-contexts.rs:3: complexity: loop may grow as O(N)
constant-contexts.rs:6: complexity: loop nesting depth is 2; work may grow as O(N^2)
constant-contexts.rs:12: complexity: loop nesting depth is 2; work may grow as O(N^2)
nayuta: scanned 1 Rust file(s), found 3 issue(s)
```

## 期待

長さ・const generic 引数は定数コンテキストなので、コンパイル時のループを外側の入力サイズに対して繰り返す実行時計算として掛け合わせないこと。定数式を解析する場合は独立した深さで扱い、走査後には実行時の深さを復元すること。

固定回数のループを O(N) 候補として報告する既存の制限は理解しています。この報告はその回数推定ではなく、評価段階の異なる処理の深さを結合してしまう問題です。

## 調査の入口

`visit_expr_repeat` の `len` と `visit_generic_argument` の const 引数など、`ExprConst`/`ItemConst` を経由しない定数コンテキストについて、#21 と同じ深さの分離が必要そうです。繰り返し式の要素側は実行時の式なので、長さだけの分離と深さの復元を回帰試験で確認できるとよさそうです。

## 確認範囲

- Linux aarch64 / Rust 1.99.1
- `cargo test --locked`: 15 passed
- #20 の元の再現例は v0.3.1 で修正済みと確認
- 上記2ケースは rustc によるコンパイル成功と実 nayuta CLI の出力を確認
- 今回の Temiya 変更4ファイルの通常解析も成功（11 heuristic candidates、parse error なし）。候補数は確定した不具合数ではありません。
