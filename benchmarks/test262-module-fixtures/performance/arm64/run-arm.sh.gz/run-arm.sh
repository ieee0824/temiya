#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-test262-module-fixtures
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-149-perf/agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-149-perf/agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-149-perf/agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-149-perf/agent-affinity-pinned.log
export TEMIYA_REVISION=d25d974b9502b9382c02ce58a0985f4c33f28910
export BENCH_NOTES='Module fixture candidate vs main cc3542e; fresh isolated release builds; original11 bodies/counts/oracles and15samples3pairs unchanged; four prespecified reports; CPU0 agent CPUs1-3; start only after builds and functional/Miri tests terminal; retain all unfavorable observations.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-149-perf/current-worker /tmp/temiya-149-perf/baseline-info.json 15 3 > /tmp/temiya-149-perf/beforeafter.json 2> /tmp/temiya-149-perf/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-149-perf/current-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-149-perf/boa.json 2> /tmp/temiya-149-perf/boa.progress
export TEMIYA_REVISION=cc3542edf098d893e9e275e1f6e7682f175e7097
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-149-perf/baseline-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-149-perf/baseline-boa.json 2> /tmp/temiya-149-perf/baseline-boa.progress
export TEMIYA_REVISION=d25d974b9502b9382c02ce58a0985f4c33f28910
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-149-perf/current-worker /tmp/temiya-149-perf/current-info.json 15 3 > /tmp/temiya-149-perf/same-binary.json 2> /tmp/temiya-149-perf/same-binary.progress
