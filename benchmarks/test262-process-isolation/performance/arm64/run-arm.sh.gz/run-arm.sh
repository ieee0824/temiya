#!/bin/bash
set -euo pipefail
export PATH=/usr/local/cargo/bin:$PATH
cd /tmp/temiya-test262-process-isolation
trap 'taskset --all-tasks --pid --cpu-list 0-3 1647005 > /tmp/temiya-150-perf/agent-affinity-restored.log; taskset --all-tasks --pid --cpu-list 0-3 1646982 >> /tmp/temiya-150-perf/agent-affinity-restored.log' EXIT
taskset --all-tasks --pid --cpu-list 1-3 1647005 > /tmp/temiya-150-perf/agent-affinity-pinned.log
taskset --all-tasks --pid --cpu-list 1-3 1646982 >> /tmp/temiya-150-perf/agent-affinity-pinned.log
export TEMIYA_REVISION=fb07e6358ff6ab8d62b7e1f8f3aa7e3e1124472a
export BENCH_NOTES='Process isolation candidate fb07e63 vs frozen149 d25d974; remote baseline de290ef has identical baseline inputs; original11 bodies/counts/oracles and15samples3pairs unchanged; all4 reports; CPU0 agent CPUs1-3; all local builds/native/MSRV/pinned/CABI checks terminal before timing; preserve unfavorable outcomes.'
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-150-perf/current-worker /tmp/temiya-150-perf/baseline-info.json 15 3 > /tmp/temiya-150-perf/beforeafter.json 2> /tmp/temiya-150-perf/beforeafter.progress
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-150-perf/current-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-150-perf/boa.json 2> /tmp/temiya-150-perf/boa.progress
export TEMIYA_REVISION=d25d974b9502b9382c02ce58a0985f4c33f28910
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-150-perf/baseline-worker /tmp/temiya-omoikane-worker-repro/build-info.json 15 3 > /tmp/temiya-150-perf/baseline-boa.json 2> /tmp/temiya-150-perf/baseline-boa.progress
export TEMIYA_REVISION=fb07e6358ff6ab8d62b7e1f8f3aa7e3e1124472a
taskset --cpu-list 0 node scripts/compare-omoikane-workloads.mjs --temiya-baseline /tmp/temiya-omoikane-workloads-v2 /tmp/temiya-150-perf/current-worker /tmp/temiya-150-perf/current-info.json 15 3 > /tmp/temiya-150-perf/same-binary.json 2> /tmp/temiya-150-perf/same-binary.progress
